package com.example.phonecleaner

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class ScannerTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private fun write(rel: String, bytes: ByteArray): File {
        val f = File(tmp.root, rel)
        f.parentFile?.mkdirs()
        f.writeBytes(bytes)
        return f
    }

    @Test
    fun nomedia_and_zero_byte_files_are_never_junk() {
        write("DCIM/.nomedia", ByteArray(0))
        write("Docs/empty.txt", ByteArray(0))
        write("Docs/photo.jpg", ByteArray(10))
        val r = Scanner.scan(tmp.root)
        assertTrue(r.none { it.file.name == ".nomedia" || it.file.name == "empty.txt" })
    }

    @Test
    fun android_dir_is_never_scanned() {
        write("Android/media/app/old.tmp", ByteArray(5))
        write("Android/data/app/cache.log", ByteArray(5))
        val r = Scanner.scan(tmp.root)
        assertTrue(r.none { it.file.path.contains("Android") })
    }

    @Test
    fun standard_dirs_are_not_listed_as_empty_but_nested_empty_dirs_are() {
        File(tmp.root, "DCIM/Camera").mkdirs()
        File(tmp.root, "Download").mkdirs()
        File(tmp.root, "Zzz/inner").mkdirs()
        val dirs = Scanner.scan(tmp.root).filter { it.category == Category.EMPTY_DIR }.map { it.file.name }.toSet()
        assertEquals(setOf("Zzz", "inner"), dirs)
    }

    @Test
    fun extensions_map_to_expected_categories() {
        write("a/x.log", ByteArray(5))
        write("a/y.bak", ByteArray(5))
        write("a/z.apk", ByteArray(5))
        val byName = Scanner.scan(tmp.root).associateBy { it.file.name }
        assertEquals(Category.TEMP, byName["x.log"]?.category)
        assertEquals(Category.BACKUP, byName["y.bak"]?.category)
        assertEquals(Category.APK, byName["z.apk"]?.category)
    }

    @Test
    fun duplicates_keep_oldest_and_reference_it() {
        val content = ByteArray(150 * 1024) { 7 }
        val a = write("A/one.bin", content)
        val b = write("B/two.bin", content)
        write("C/three.bin", ByteArray(150 * 1024) { 8 })
        a.setLastModified(1_000_000_000_000L)
        b.setLastModified(1_100_000_000_000L)
        val dups = Scanner.scan(tmp.root).filter { it.category == Category.DUPLICATE }
        assertEquals(1, dups.size)
        assertEquals(b, dups[0].file)
        assertNotNull(dups[0].keep)
        assertEquals(a, dups[0].keep)
    }

    @Test
    fun identical_is_true_only_for_byte_equal_files() {
        val a = write("A/a.bin", ByteArray(300 * 1024) { 1 })
        val b = write("B/b.bin", ByteArray(300 * 1024) { 1 })
        val c = write("C/c.bin", ByteArray(300 * 1024) { 1 }.also { it[100_000] = 2 })
        assertTrue(Scanner.identical(a, b))
        assertTrue(!Scanner.identical(a, c))
        assertTrue(!Scanner.identical(a, a))
        assertTrue(!Scanner.identical(a, File(tmp.root, "missing.bin")))
    }

    @Test
    fun files_differing_outside_sampled_regions_are_not_duplicates() {
        // البايت 100000 خارج عينات البداية/الوسط/النهاية، فيجب أن يكشفه الفحص الكامل
        write("A/a.bin", ByteArray(300 * 1024) { 1 })
        write("B/b.bin", ByteArray(300 * 1024) { 1 }.also { it[100_000] = 2 })
        assertTrue(Scanner.scan(tmp.root).none { it.category == Category.DUPLICATE })
    }
}
