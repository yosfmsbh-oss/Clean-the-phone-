package com.example.phonecleaner

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.webkit.MimeTypeMap
import android.widget.Toast
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.text.format.Formatter
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel

private val Blue = Color(0xFF0A84FF)
private val Red = Color(0xFFFF3B30)
private val Gray = Color(0xFF8E8E93)
private val Green = Color(0xFF34C759)
private val Gap = 12.dp

private object Ios {
    val dark @Composable get() = isSystemInDarkTheme()
    val bg @Composable get() = if (dark) Color.Black else Color(0xFFF2F2F7)
    val cell @Composable get() = if (dark) Color(0xFF1C1C1E) else Color.White
    val sep @Composable get() = if (dark) Color(0xFF38383A) else Color(0xFFD1D1D6)
    val track @Composable get() = if (dark) Color(0xFF2C2C2E) else Color(0xFFE5E5EA)
    val text @Composable get() = if (dark) Color.White else Color.Black
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { App() }
            }
        }
    }
}

private val legacyPerms = arrayOf(
    Manifest.permission.READ_EXTERNAL_STORAGE,
    Manifest.permission.WRITE_EXTERNAL_STORAGE
)

private fun hasAccess(ctx: Context): Boolean =
    if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else legacyPerms.all {
        ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
    }

/** بعض الأجهزة لا تدعم شاشة "التطبيق الواحد"، فنجرب بدائل بالترتيب. */
@RequiresApi(Build.VERSION_CODES.R)
private fun openAllFilesSettings(ctx: Context) {
    val uri = Uri.parse("package:${ctx.packageName}")
    val attempts = listOf(
        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, uri),
        Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)
    )
    for (intent in attempts) {
        try {
            ctx.startActivity(intent)
            return
        } catch (e: ActivityNotFoundException) {
            // جرّب التالي
        }
    }
}

private fun noticeText(ctx: Context, n: Notice): String = when (n) {
    is Notice.Deleted -> {
        val parts = ArrayList<String>()
        if (n.deletedCount > 0) parts.add(ctx.getString(R.string.notice_freed, n.deletedCount, Formatter.formatFileSize(ctx, n.deletedBytes)))
        if (n.trashedCount > 0) parts.add(ctx.getString(R.string.notice_trashed, n.trashedCount, Formatter.formatFileSize(ctx, n.trashedBytes)))
        if (n.skipped > 0) parts.add(ctx.getString(R.string.notice_skipped, n.skipped))
        if (n.failed > 0) parts.add(ctx.getString(R.string.notice_failed, n.failed))
        if (parts.isEmpty()) ctx.getString(R.string.notice_nothing) else parts.joinToString("\n")
    }
    is Notice.Restored -> {
        val parts = ArrayList<String>()
        if (n.ok > 0) parts.add(ctx.getString(R.string.notice_restored, n.ok))
        if (n.failed > 0) parts.add(ctx.getString(R.string.notice_restore_failed, n.failed))
        if (parts.isEmpty()) ctx.getString(R.string.notice_nothing) else parts.joinToString("\n")
    }
    is Notice.TrashEmptied -> ctx.getString(R.string.notice_trash_emptied, Formatter.formatFileSize(ctx, n.bytes))
}

private fun progressText(ctx: Context, p: ScanProgress?): String = when {
    p == null -> ctx.getString(R.string.scanning_listing, 0)
    p.stage == Scanner.Stage.LISTING -> ctx.getString(R.string.scanning_listing, p.done)
    else -> ctx.getString(R.string.scanning_analyzing, p.done, p.total)
}

@Composable
fun App(vm: CleanerViewModel = viewModel()) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasAccess(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { granted = hasAccess(ctx) }
    val legacyLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted = hasAccess(ctx) }

    var confirm by remember { mutableStateOf(false) }
    var confirmEmpty by remember { mutableStateOf(false) }
    var open by remember { mutableStateOf<Category?>(null) }
    var trashOpen by remember { mutableStateOf(false) }
    var preview by remember { mutableStateOf<JunkItem?>(null) }
    val grouped = remember(vm.items) { vm.items.groupBy { it.category } }
    val selectedItems = remember(vm.items, vm.selected) { vm.items.filter { it.file in vm.selected } }
    val selSize = remember(selectedItems) { selectedItems.sumOf { it.size } }
    val trashSize = remember(vm.trashEntries) { vm.trashEntries.sumOf { it.size } }
    fun fmt(b: Long): String = Formatter.formatFileSize(ctx, b)
    val locked = vm.busy || vm.scanning

    Scaffold(
        containerColor = Ios.bg,
        contentColor = Ios.text,
        bottomBar = {
            if (granted && selectedItems.isNotEmpty()) {
                Box(Modifier.fillMaxWidth().background(Ios.cell).navigationBarsPadding().padding(16.dp)) {
                    Button(
                        onClick = { confirm = true },
                        enabled = !locked,
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Red, contentColor = Color.White,
                            disabledContainerColor = Red.copy(alpha = 0.5f), disabledContentColor = Color.White
                        )
                    ) {
                        Text(
                            stringResource(R.string.delete_button, selectedItems.size, fmt(selSize)),
                            fontSize = 17.sp, fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
        ) {
            item(key = "title") {
                Text(
                    stringResource(R.string.app_name), fontSize = 34.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp, bottom = Gap)
                )
            }
            item(key = "ring") {
                Box(Modifier.padding(bottom = Gap)) { StorageRing(vm.storageTick) }
            }

            if (!granted) {
                item(key = "perm") {
                    Column(
                        Modifier.fillMaxWidth().padding(bottom = Gap)
                            .clip(RoundedCornerShape(16.dp)).background(Ios.cell).padding(16.dp)
                    ) {
                        Text(stringResource(R.string.permission_text), fontSize = 15.sp, color = Gray)
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = {
                                if (Build.VERSION.SDK_INT >= 30) openAllFilesSettings(ctx)
                                else legacyLauncher.launch(legacyPerms)
                            },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Color.White)
                        ) { Text(stringResource(R.string.allow_access), fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
                    }
                }
            } else {
                item(key = "scan") {
                    Row(
                        Modifier.fillMaxWidth().padding(bottom = Gap),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = vm::scan,
                            enabled = !locked,
                            modifier = Modifier.weight(1f).height(50.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Blue, contentColor = Color.White,
                                disabledContainerColor = Blue.copy(alpha = 0.5f), disabledContentColor = Color.White
                            )
                        ) {
                            Text(
                                if (vm.scanning) progressText(ctx, vm.progress) else stringResource(R.string.scan_button),
                                fontSize = 17.sp, fontWeight = FontWeight.SemiBold
                            )
                        }
                        if (vm.scanning) {
                            Button(
                                onClick = vm::cancelScan,
                                modifier = Modifier.height(50.dp),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Gray, contentColor = Color.White)
                            ) { Text(stringResource(R.string.cancel), fontSize = 15.sp) }
                        }
                    }
                }
                if (vm.busy) {
                    item(key = "working") {
                        Text(
                            stringResource(R.string.working), color = Gray, fontSize = 15.sp,
                            modifier = Modifier.fillMaxWidth().padding(bottom = Gap), textAlign = TextAlign.Center
                        )
                    }
                }
                vm.error?.let { e ->
                    item(key = "error") {
                        Text(
                            stringResource(R.string.scan_error, e), color = Red, fontSize = 15.sp,
                            modifier = Modifier.fillMaxWidth().padding(bottom = Gap), textAlign = TextAlign.Center
                        )
                    }
                }
                vm.notice?.let { n ->
                    item(key = "notice") {
                        Text(
                            noticeText(ctx, n), color = Blue, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.fillMaxWidth().padding(bottom = Gap), textAlign = TextAlign.Center
                        )
                    }
                }
                if (vm.scanned && !vm.scanning && vm.items.isEmpty()) {
                    item(key = "clean") {
                        Text(
                            stringResource(R.string.clean_device), color = Gray, fontSize = 17.sp,
                            modifier = Modifier.fillMaxWidth().padding(bottom = Gap), textAlign = TextAlign.Center
                        )
                    }
                }

                Category.entries.forEach { cat ->
                    val list = grouped[cat] ?: return@forEach
                    val isOpen = open == cat
                    item(key = "h-${cat.name}") {
                        val all = list.all { it.file in vm.selected }
                        val shape = if (isOpen) RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp) else RoundedCornerShape(16.dp)
                        Row(
                            Modifier.fillMaxWidth()
                                .padding(bottom = if (isOpen) 0.dp else Gap)
                                .clip(shape).background(Ios.cell)
                                .clickable { open = if (isOpen) null else cat }
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Check(all) { vm.setCategory(cat, !all) }
                            Spacer(Modifier.size(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(stringResource(cat.titleRes), fontSize = 17.sp)
                                Text(
                                    stringResource(R.string.items_size, list.size, fmt(list.sumOf { it.size })),
                                    fontSize = 13.sp, color = Gray
                                )
                            }
                            Text(if (isOpen) "▾" else "‹", fontSize = 20.sp, color = Gray)
                        }
                    }
                    if (isOpen) {
                        items(list, key = { "r-${cat.name}-${it.file.path}" }) { row ->
                            ItemRow(row, row.file in vm.selected, { b -> fmt(b) }, { preview = row }) { vm.toggle(row.file) }
                        }
                        item(key = "c-${cat.name}") { BottomCap() }
                    }
                }

                if (vm.trashEntries.isNotEmpty()) {
                    item(key = "trash-h") {
                        val shape = if (trashOpen) RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp) else RoundedCornerShape(16.dp)
                        Column(
                            Modifier.fillMaxWidth()
                                .padding(bottom = if (trashOpen) 0.dp else Gap)
                                .clip(shape).background(Ios.cell)
                        ) {
                            Row(
                                Modifier.fillMaxWidth().clickable { trashOpen = !trashOpen }
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(stringResource(R.string.trash_title), fontSize = 17.sp)
                                    Text(
                                        stringResource(R.string.items_size, vm.trashEntries.size, fmt(trashSize)),
                                        fontSize = 13.sp, color = Gray
                                    )
                                }
                                Text(if (trashOpen) "▾" else "‹", fontSize = 20.sp, color = Gray)
                            }
                            Row(Modifier.padding(horizontal = 8.dp)) {
                                TextButton(onClick = vm::restoreAll, enabled = !locked) {
                                    Text(stringResource(R.string.restore_all), color = Blue)
                                }
                                TextButton(onClick = { confirmEmpty = true }, enabled = !locked) {
                                    Text(stringResource(R.string.empty_trash), color = Red)
                                }
                            }
                        }
                    }
                    if (trashOpen) {
                        items(vm.trashEntries, key = { "t-${it.id}" }) { e ->
                            Column(Modifier.fillMaxWidth().background(Ios.cell)) {
                                HorizontalDivider(Modifier.padding(start = 16.dp), thickness = 0.5.dp, color = Ios.sep)
                                Row(
                                    Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(e.original.name, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(e.original.parent ?: "", fontSize = 12.sp, color = Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    Text(fmt(e.size), fontSize = 13.sp, color = Gray)
                                    TextButton(onClick = { vm.restore(e) }, enabled = !locked) {
                                        Text(stringResource(R.string.restore), color = Blue)
                                    }
                                }
                            }
                        }
                        item(key = "trash-cap") { BottomCap() }
                    }
                }
            }
        }
    }

    preview?.let { p -> PreviewDialog(p, { b -> fmt(b) }) { preview = null } }

    if (confirm) {
        val breakdown = selectedItems.groupBy { it.category }
        AlertDialog(
            onDismissRequest = { confirm = false },
            shape = RoundedCornerShape(14.dp),
            title = { Text(stringResource(R.string.confirm_title, selectedItems.size), textAlign = TextAlign.Center) },
            text = {
                Column {
                    Category.entries.forEach { c ->
                        val l = breakdown[c] ?: return@forEach
                        Text("• ${stringResource(c.titleRes)}: ${l.size} · ${fmt(l.sumOf { it.size })}", fontSize = 15.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(stringResource(R.string.confirm_note), fontSize = 13.sp, color = Gray)
                }
            },
            confirmButton = {
                TextButton(onClick = { confirm = false; vm.deleteSelected() }) {
                    Text(stringResource(R.string.confirm_ok), color = Red, fontWeight = FontWeight.SemiBold)
                }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text(stringResource(R.string.cancel), color = Blue) } }
        )
    }

    if (confirmEmpty) {
        AlertDialog(
            onDismissRequest = { confirmEmpty = false },
            shape = RoundedCornerShape(14.dp),
            title = { Text(stringResource(R.string.empty_trash_title), textAlign = TextAlign.Center) },
            text = { Text(stringResource(R.string.empty_trash_msg, vm.trashEntries.size, fmt(trashSize))) },
            confirmButton = {
                TextButton(onClick = { confirmEmpty = false; vm.emptyTrash() }) {
                    Text(stringResource(R.string.empty_trash), color = Red, fontWeight = FontWeight.SemiBold)
                }
            },
            dismissButton = { TextButton(onClick = { confirmEmpty = false }) { Text(stringResource(R.string.cancel), color = Blue) } }
        )
    }
}

@Composable
private fun ItemRow(row: JunkItem, checked: Boolean, fmt: (Long) -> String, onInfo: () -> Unit, onToggle: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Ios.cell)) {
        HorizontalDivider(Modifier.padding(start = 52.dp), thickness = 0.5.dp, color = Ios.sep)
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onToggle)
                .padding(start = 52.dp, end = 16.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Check(checked, 20, onToggle)
            Spacer(Modifier.size(10.dp))
            Column(Modifier.weight(1f)) {
                Text(row.file.name, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(row.file.parent ?: "", fontSize = 12.sp, color = Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
                row.keep?.let {
                    Text(
                        stringResource(R.string.keeps_copy, it.path),
                        fontSize = 12.sp, color = Blue, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Text(fmt(row.size), fontSize = 13.sp, color = Gray)
            Text(
                "ⓘ", fontSize = 22.sp, color = Blue,
                modifier = Modifier.clickable(onClick = onInfo).padding(start = 8.dp, top = 4.dp, bottom = 4.dp, end = 2.dp)
            )
        }
    }
}

private val imageExt = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic")
private val videoExt = setOf("mp4", "mkv", "3gp", "mov", "webm", "avi")

private fun loadThumb(f: File, max: Int = 600): Bitmap? = try {
    when (f.extension.lowercase()) {
        in imageExt -> {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, o)
            var s = 1
            while (o.outWidth / (s * 2) >= max && o.outHeight / (s * 2) >= max) s *= 2
            BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
        }
        in videoExt -> {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(f.path)
                r.getFrameAtTime(0)
            } finally {
                r.release()
            }
        }
        else -> null
    }
} catch (e: Exception) {
    null
} catch (e: OutOfMemoryError) {
    null
}

private fun openFile(ctx: Context, f: File) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(ctx, ctx.getString(R.string.open_failed), Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun FileCard(label: String?, file: File, fmt: (Long) -> String) {
    val ctx = LocalContext.current
    val thumb by produceState<Bitmap?>(null, file) {
        value = withContext(Dispatchers.IO) { loadThumb(file) }
    }
    Column(Modifier.fillMaxWidth()) {
        label?.let { Text(it, fontSize = 13.sp, color = Blue, fontWeight = FontWeight.SemiBold) }
        thumb?.let {
            Image(
                it.asImageBitmap(), null,
                Modifier.fillMaxWidth().heightIn(max = 200.dp).padding(vertical = 6.dp).clip(RoundedCornerShape(10.dp)),
                contentScale = ContentScale.Fit
            )
        }
        if (!file.exists()) {
            Text(stringResource(R.string.file_missing), color = Red, fontSize = 14.sp)
        } else {
            Text(file.name, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(file.path, fontSize = 12.sp, color = Gray)
            Text(
                "${fmt(file.length())} · ${DateFormat.getDateTimeInstance().format(Date(file.lastModified()))}",
                fontSize = 12.sp, color = Gray
            )
            if (file.extension.lowercase() != "apk") {
                TextButton(onClick = { openFile(ctx, file) }) {
                    Text(stringResource(R.string.open_file), color = Blue)
                }
            }
        }
    }
}

@Composable
private fun PreviewDialog(row: JunkItem, fmt: (Long) -> String, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var checking by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<Boolean?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(14.dp),
        title = { Text(stringResource(R.string.preview_title)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                FileCard(if (row.keep != null) stringResource(R.string.dup_this) else null, row.file, fmt)
                row.keep?.let { k ->
                    HorizontalDivider(Modifier.padding(vertical = 10.dp), thickness = 0.5.dp, color = Ios.sep)
                    FileCard(stringResource(R.string.dup_kept), k, fmt)
                    Spacer(Modifier.height(8.dp))
                    when {
                        checking -> Text(stringResource(R.string.verifying), color = Gray, fontSize = 14.sp)
                        result == true -> Text(
                            stringResource(R.string.match_yes), color = Green,
                            fontSize = 15.sp, fontWeight = FontWeight.SemiBold
                        )
                        result == false -> Text(
                            stringResource(R.string.match_no), color = Red,
                            fontSize = 15.sp, fontWeight = FontWeight.SemiBold
                        )
                        else -> TextButton(onClick = {
                            checking = true
                            scope.launch {
                                result = withContext(Dispatchers.IO) { Scanner.identical(row.file, k) }
                                checking = false
                            }
                        }) { Text(stringResource(R.string.verify_btn), color = Blue) }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.close), color = Blue) } }
    )
}

@Composable
private fun BottomCap() {
    Box(
        Modifier.fillMaxWidth().padding(bottom = Gap).height(12.dp)
            .clip(RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp))
            .background(Ios.cell)
    )
}

@Composable
fun Check(on: Boolean, size: Int = 24, onClick: () -> Unit) {
    Box(
        Modifier.size(size.dp).clip(CircleShape)
            .background(if (on) Blue else Color.Transparent)
            .border(1.5.dp, if (on) Blue else Gray, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { if (on) Text("✓", color = Color.White, fontSize = (size * 0.55f).sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun StorageRing(refresh: Int) {
    val ctx = LocalContext.current
    val (total, free) = remember(refresh) {
        val stat = StatFs(Environment.getExternalStorageDirectory().path)
        (stat.blockCountLong * stat.blockSizeLong) to stat.availableBytes
    }
    val frac = if (total > 0) (total - free).toFloat() / total else 0f
    val track = Ios.track
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Ios.cell).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(150.dp)) {
                val sw = 14.dp.toPx()
                val tl = Offset(sw / 2, sw / 2)
                val sz = Size(size.width - sw, size.height - sw)
                drawArc(track, 0f, 360f, false, tl, sz, style = Stroke(sw))
                drawArc(Blue, -90f, 360f * frac, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${(frac * 100).toInt()}%", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.ring_used), fontSize = 13.sp, color = Gray)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            stringResource(R.string.ring_free, Formatter.formatFileSize(ctx, free), Formatter.formatFileSize(ctx, total)),
            fontSize = 15.sp, color = Gray
        )
    }
}
