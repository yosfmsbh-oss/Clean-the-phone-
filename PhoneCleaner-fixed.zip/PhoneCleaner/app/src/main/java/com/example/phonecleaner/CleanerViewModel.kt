package com.example.phonecleaner

import android.app.Application
import android.media.MediaScannerConnection
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class ScanProgress(val stage: Scanner.Stage, val done: Int, val total: Int)

sealed interface Notice {
    data class Deleted(
        val trashedCount: Int,
        val trashedBytes: Long,
        val deletedCount: Int,
        val deletedBytes: Long,
        val skipped: Int,
        val failed: Int
    ) : Notice

    data class Restored(val ok: Int, val failed: Int) : Notice
    data class TrashEmptied(val bytes: Long) : Notice
}

class CleanerViewModel(app: Application) : AndroidViewModel(app) {
    private val trash = Trash(app)
    private var scanJob: Job? = null

    var scanning by mutableStateOf(false)
        private set
    var scanned by mutableStateOf(false)
        private set
    var busy by mutableStateOf(false)
        private set
    var progress by mutableStateOf<ScanProgress?>(null)
        private set
    var items by mutableStateOf<List<JunkItem>>(emptyList())
        private set
    var selected by mutableStateOf<Set<File>>(emptySet())
        private set
    var notice by mutableStateOf<Notice?>(null)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var trashEntries by mutableStateOf<List<Trash.Entry>>(emptyList())
        private set
    var storageTick by mutableIntStateOf(0)
        private set

    init {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { trash.purgeOlderThan(TRASH_DAYS * DAY_MS) }
                reloadTrash()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // السلة اختيارية؛ فشل تنظيفها لا يمنع استخدام التطبيق
            }
        }
    }

    fun scan() {
        if (scanning || busy) return
        scanning = true
        error = null
        notice = null
        progress = null
        scanJob = viewModelScope.launch {
            try {
                val ctx = getApplication<Application>()
                val found = withContext(Dispatchers.IO) {
                    val list = Scanner.scan(
                        Environment.getExternalStorageDirectory(),
                        { ensureActive() }
                    ) { stage, done, total -> progress = ScanProgress(stage, done, total) }
                    val caches = listOfNotNull(ctx.cacheDir, ctx.externalCacheDir).flatMap { d ->
                        d.walkTopDown().filter { it.isFile }
                            .map { JunkItem(it, Category.APP_CACHE, it.length()) }.toList()
                    }
                    (list + caches).sortedByDescending { it.size }
                }
                items = found
                selected = found.filter { it.category.preselect }.map { it.file }.toSet()
                scanned = true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                error = e.message ?: e.javaClass.simpleName
            } finally {
                scanning = false
                progress = null
            }
        }
    }

    fun cancelScan() {
        scanJob?.cancel()
    }

    fun toggle(f: File) {
        selected = if (f in selected) selected - f else selected + f
    }

    fun setCategory(c: Category, on: Boolean) {
        val files = items.filter { it.category == c }.map { it.file }
        selected = if (on) selected + files else selected - files.toSet()
    }

    fun deleteSelected() {
        if (busy || scanning) return
        val sel = selected
        val snapshot = items.filter { it.file in sel }
        if (snapshot.isEmpty()) return
        busy = true
        viewModelScope.launch {
            try {
                val out = withContext(Dispatchers.IO) { performDelete(snapshot) }
                notice = out.notice
                items = items.filter { it.file !in out.removed }
                selected = selected - out.removed
                reloadTrash()
                storageTick++
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                error = e.message ?: e.javaClass.simpleName
            } finally {
                busy = false
            }
        }
    }

    fun restore(e: Trash.Entry) = trashOp {
        val r = trash.restore(e)
        if (r != null) scanMedia(listOf(r.path))
        Notice.Restored(if (r != null) 1 else 0, if (r == null) 1 else 0)
    }

    fun restoreAll() = trashOp {
        var ok = 0
        var failed = 0
        val paths = ArrayList<String>()
        for (e in trash.list()) {
            val r = trash.restore(e)
            if (r != null) { ok++; paths.add(r.path) } else failed++
        }
        scanMedia(paths)
        Notice.Restored(ok, failed)
    }

    fun emptyTrash() = trashOp {
        val all = trash.list()
        all.forEach { trash.purge(it) }
        Notice.TrashEmptied(all.sumOf { it.size })
    }

    private fun trashOp(block: () -> Notice) {
        if (busy || scanning) return
        busy = true
        viewModelScope.launch {
            try {
                notice = withContext(Dispatchers.IO) { block() }
                reloadTrash()
                storageTick++
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                error = e.message ?: e.javaClass.simpleName
            } finally {
                busy = false
            }
        }
    }

    private suspend fun reloadTrash() {
        trashEntries = withContext(Dispatchers.IO) { trash.list() }
    }

    private class Outcome(val notice: Notice.Deleted, val removed: Set<File>)

    private fun performDelete(snapshot: List<JunkItem>): Outcome {
        val selectedFiles = snapshot.map { it.file }.toSet()
        val removed = HashSet<File>()
        val mediaPaths = ArrayList<String>()
        var trashedCount = 0
        var trashedBytes = 0L
        var deletedCount = 0
        var deletedBytes = 0L
        var skipped = 0
        var failed = 0

        for (item in snapshot.filter { it.category != Category.EMPTY_DIR }) {
            val f = item.file
            // تأكد أن الملف لم يتغير منذ الفحص
            if (!f.isFile || f.length() != item.size || f.lastModified() != item.modified) {
                skipped++; continue
            }
            // المكرر: لا نحذفه إلا إذا بقيت النسخة المحفوظة سليمة وغير محددة للحذف
            if (item.category == Category.DUPLICATE) {
                val k = item.keep
                if (k == null || !k.isFile || k.length() != item.size || k in selectedFiles) {
                    skipped++; continue
                }
            }
            if (item.category.permanent) {
                if (f.delete()) {
                    removed.add(f); deletedCount++; deletedBytes += item.size; mediaPaths.add(f.path)
                } else failed++
            } else {
                if (trash.put(f)) {
                    removed.add(f); trashedCount++; trashedBytes += item.size; mediaPaths.add(f.path)
                } else failed++
            }
        }

        // المجلدات الفارغة: الأعمق أولًا. File.delete() يفشل بأمان إن لم يكن المجلد فارغًا.
        val dirs = snapshot.filter { it.category == Category.EMPTY_DIR }
            .sortedByDescending { it.file.path.length }
        for (d in dirs) {
            if (d.file.isDirectory && d.file.delete()) {
                removed.add(d.file); deletedCount++
            } else skipped++
        }

        scanMedia(mediaPaths)
        return Outcome(
            Notice.Deleted(trashedCount, trashedBytes, deletedCount, deletedBytes, skipped, failed),
            removed
        )
    }

    private fun scanMedia(paths: List<String>) {
        if (paths.isEmpty()) return
        MediaScannerConnection.scanFile(getApplication<Application>(), paths.toTypedArray(), null, null)
    }

    private companion object {
        const val TRASH_DAYS = 30L
        const val DAY_MS = 24L * 60 * 60 * 1000
    }
}
