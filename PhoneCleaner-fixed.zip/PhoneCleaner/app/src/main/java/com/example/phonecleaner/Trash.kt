package com.example.phonecleaner

import android.content.Context
import java.io.File
import java.io.IOException
import java.util.Properties
import java.util.UUID

/**
 * سلة محذوفات خاصة بالتطبيق: كل ملف يُخزَّن باسم عشوائي مع ملف وصفي يحمل مساره الأصلي.
 * تُخزَّن في مجلد الملفات الخارجي للتطبيق (نفس وحدة التخزين، فالنقل سريع عادةً).
 */
class Trash(private val ctx: Context) {
    data class Entry(
        val id: String,
        val original: File,
        val size: Long,
        val trashedAt: Long,
        val stored: File
    )

    private val dir: File by lazy {
        (ctx.getExternalFilesDir("trash") ?: File(ctx.filesDir, "trash")).apply { mkdirs() }
    }

    fun put(f: File): Boolean {
        val id = UUID.randomUUID().toString()
        val stored = File(dir, "$id.bin")
        val meta = File(dir, "$id.meta")
        return try {
            val p = Properties()
            p.setProperty("path", f.path)
            p.setProperty("size", f.length().toString())
            p.setProperty("time", System.currentTimeMillis().toString())
            meta.outputStream().use { p.store(it, null) }
            if (move(f, stored)) true else { meta.delete(); false }
        } catch (e: IOException) {
            meta.delete(); stored.delete(); false
        }
    }

    fun list(): List<Entry> {
        val metas = dir.listFiles { f -> f.extension == "meta" } ?: return emptyList()
        return metas.mapNotNull { m ->
            try {
                val p = Properties()
                m.inputStream().use { p.load(it) }
                val id = m.nameWithoutExtension
                val stored = File(dir, "$id.bin")
                if (!stored.exists()) { m.delete(); return@mapNotNull null }
                Entry(id, File(p.getProperty("path")), p.getProperty("size").toLong(),
                    p.getProperty("time").toLong(), stored)
            } catch (e: Exception) {
                null
            }
        }.sortedByDescending { it.trashedAt }
    }

    /** يعيد الملف إلى مساره الأصلي (أو باسم بديل إن كان المسار مشغولًا). يعيد null عند الفشل. */
    fun restore(e: Entry): File? {
        val target = uniqueTarget(e.original)
        target.parentFile?.mkdirs()
        return if (move(e.stored, target)) {
            File(dir, "${e.id}.meta").delete()
            target
        } else null
    }

    fun purge(e: Entry) {
        e.stored.delete()
        File(dir, "${e.id}.meta").delete()
    }

    fun purgeOlderThan(maxAgeMs: Long) {
        val now = System.currentTimeMillis()
        list().filter { now - it.trashedAt > maxAgeMs }.forEach { purge(it) }
    }

    private fun uniqueTarget(orig: File): File {
        if (!orig.exists()) return orig
        val base = orig.nameWithoutExtension
        val ext = orig.extension.let { if (it.isEmpty()) "" else ".$it" }
        return generateSequence(1) { it + 1 }
            .map { File(orig.parentFile, "$base (مستعاد $it)$ext") }
            .first { !it.exists() }
    }

    private fun move(src: File, dst: File): Boolean {
        if (src.renameTo(dst)) return true
        return try {
            src.copyTo(dst, overwrite = false)
            if (dst.length() == src.length() && src.delete()) true else { dst.delete(); false }
        } catch (e: IOException) {
            dst.delete(); false
        }
    }
}
