package com.example.phonecleaner

import androidx.annotation.StringRes
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.RandomAccessFile
import java.security.MessageDigest

enum class Category(
    @StringRes val titleRes: Int,
    /** هل تُحدَّد تلقائيًا بعد الفحص؟ فقط الفئات منخفضة الخطورة. */
    val preselect: Boolean,
    /** تُحذف نهائيًا (بدل نقلها إلى السلة). */
    val permanent: Boolean = false
) {
    TEMP(R.string.cat_temp, true),
    APP_CACHE(R.string.cat_app_cache, true, permanent = true),
    EMPTY_DIR(R.string.cat_empty_dir, true, permanent = true),
    DUPLICATE(R.string.cat_duplicate, false),
    BACKUP(R.string.cat_backup, false),
    APK(R.string.cat_apk, false),
    OLD_DOWNLOADS(R.string.cat_old_downloads, false),
    LARGE(R.string.cat_large, false)
}

/**
 * @param modified وقت التعديل لحظة الفحص، يُستخدم للتأكد أن الملف لم يتغير قبل حذفه.
 * @param keep للمكررات: النسخة التي ستبقى.
 */
data class JunkItem(
    val file: File,
    val category: Category,
    val size: Long,
    val modified: Long = file.lastModified(),
    val keep: File? = null
)

object Scanner {
    enum class Stage { LISTING, ANALYZING }

    private val tempExt = setOf("tmp", "temp", "dmp", "log", "thumb")
    private val backupExt = setOf("bak", "old", "backup")
    const val LARGE_SIZE = 50L * 1024 * 1024
    private const val MIN_DUP_SIZE = 100L * 1024
    private const val DAY_MS = 24L * 60 * 60 * 1000
    private const val SAMPLE = 64 * 1024

    /** مجلدات النظام القياسية: لا تُعرض كـ"فارغة" أبدًا. */
    private val standardDirs = listOf(
        "DCIM", "Pictures", "Download", "Movies", "Music", "Documents", "Podcasts",
        "Ringtones", "Alarms", "Notifications", "Audiobooks", "Recordings",
        "DCIM/Camera", "DCIM/Screenshots", "Pictures/Screenshots"
    )

    private class Pending(val file: File, val size: Long, val modified: Long, val base: Category?)

    fun scan(
        root: File,
        checkCancelled: () -> Unit = {},
        onProgress: (Stage, Int, Int) -> Unit = { _, _, _ -> }
    ): List<JunkItem> {
        val out = ArrayList<JunkItem>()
        val pending = ArrayList<Pending>()
        val downloads = File(root, "Download")
        val keepDirs = standardDirs.map { File(root, it).path }.toSet()
        val now = System.currentTimeMillis()
        var count = 0

        /** يعيد true إذا كان المجلد فارغًا فعليًا (أو يحوي مجلدات فارغة فقط ستُزال). */
        fun walk(dir: File, inThumbs: Boolean): Boolean {
            checkCancelled()
            val children = dir.listFiles() ?: return false // غير مقروء: نعتبره غير فارغ
            var empty = true
            for (c in children) {
                if (c.isDirectory) {
                    if (isSymlink(dir, c)) { empty = false; continue }
                    val isThumbs = c.name == ".thumbnails"
                    // Android/ (data, obb, media) مستثناة كليًا، والمجلدات المخفية تخص تطبيقات أخرى
                    if (dir.path == root.path && c.name == "Android") { empty = false; continue }
                    if (c.name.startsWith(".") && !isThumbs) { empty = false; continue }
                    val childEmpty = walk(c, isThumbs)
                    if (childEmpty && c.path !in keepDirs) {
                        out.add(JunkItem(c, Category.EMPTY_DIR, 0L))
                    } else {
                        empty = false
                    }
                    continue
                }

                empty = false
                count++
                if (count % 200 == 0) onProgress(Stage.LISTING, count, 0)

                val name = c.name
                if (name == ".nomedia") continue
                if (name.startsWith(".") && !inThumbs) continue

                val size = c.length()
                val modified = c.lastModified()
                val ext = c.extension.lowercase()
                val special = when {
                    inThumbs || ext in tempExt -> Category.TEMP
                    ext == "apk" -> Category.APK
                    ext in backupExt -> Category.BACKUP
                    else -> null
                }
                if (special != null) {
                    out.add(JunkItem(c, special, size, modified))
                    continue
                }
                val base = when {
                    size >= LARGE_SIZE -> Category.LARGE
                    c.startsWith(downloads) && now - modified > 30 * DAY_MS -> Category.OLD_DOWNLOADS
                    else -> null
                }
                if (size >= MIN_DUP_SIZE) {
                    pending.add(Pending(c, size, modified, base))
                } else if (base != null) {
                    out.add(JunkItem(c, base, size, modified))
                }
            }
            return empty
        }

        walk(root, false)
        onProgress(Stage.LISTING, count, 0)

        // المكررات: نفس الحجم ← بصمة جزئية ← بصمة كاملة. نُبقي أقدم نسخة (ثم أقصر مسار).
        val sizeGroups = pending.groupBy { it.size }.values.filter { it.size > 1 }
        val total = sizeGroups.sumOf { it.size }
        var done = 0
        val dupExtras = HashMap<File, JunkItem>()
        for (group in sizeGroups) {
            checkCancelled()
            for ((quick, g1) in group.groupBy { quickHash(it.file, it.size, checkCancelled) }) {
                if (quick != null && g1.size > 1) {
                    for ((full, g2) in g1.groupBy { fullHash(it.file, checkCancelled) }) {
                        if (full == null || g2.size < 2) continue
                        val sorted = g2.sortedWith(
                            compareBy<Pending>({ it.modified }, { it.file.path.length }, { it.file.path })
                        )
                        val keeper = sorted.first()
                        for (p in sorted.drop(1)) {
                            // تأكيد نهائي بايت ببايت (البصمة وحدها لا تكفي نظريًا)
                            if (!identical(p.file, keeper.file, checkCancelled)) continue
                            dupExtras[p.file] = JunkItem(p.file, Category.DUPLICATE, p.size, p.modified, keeper.file)
                        }
                    }
                }
                done += g1.size
                onProgress(Stage.ANALYZING, done, total)
            }
        }

        for (p in pending) {
            val dup = dupExtras[p.file]
            if (dup != null) out.add(dup)
            else if (p.base != null) out.add(JunkItem(p.file, p.base, p.size, p.modified))
        }
        return out.sortedByDescending { it.size }
    }

    /**
     * مقارنة بايت ببايت: هل الملفان متطابقان تمامًا؟
     * تعيد false إذا كان أحدهما غير موجود/غير مقروء، أو كانا نفس الملف فعليًا (رابط).
     */
    fun identical(a: File, b: File, check: () -> Unit = {}): Boolean = try {
        if (!a.isFile || !b.isFile) false
        else if (a.canonicalFile == b.canonicalFile) false
        else if (a.length() != b.length()) false
        else a.inputStream().use { ia ->
            b.inputStream().use { ib ->
                val ba = ByteArray(64 * 1024)
                val bb = ByteArray(64 * 1024)
                var same = true
                while (same) {
                    check()
                    val na = readFill(ia, ba)
                    val nb = readFill(ib, bb)
                    if (na != nb) {
                        same = false
                    } else if (na <= 0) {
                        break
                    } else {
                        for (i in 0 until na) {
                            if (ba[i] != bb[i]) { same = false; break }
                        }
                    }
                }
                same
            }
        }
    } catch (e: IOException) {
        false
    } catch (e: SecurityException) {
        false
    }

    private fun readFill(s: InputStream, buf: ByteArray): Int {
        var n = 0
        while (n < buf.size) {
            val r = s.read(buf, n, buf.size - n)
            if (r < 0) break
            n += r
        }
        return n
    }

    private fun isSymlink(parent: File, child: File): Boolean = try {
        child.canonicalFile != File(parent.canonicalFile, child.name)
    } catch (e: IOException) {
        true
    }

    private fun hex(md: MessageDigest) = md.digest().joinToString("") { "%02x".format(it) }

    /** بصمة من 3 عينات (بداية/وسط/نهاية) للملفات الكبيرة، وكاملة للصغيرة. */
    private fun quickHash(f: File, size: Long, check: () -> Unit): String? {
        if (size <= 3L * SAMPLE) return fullHash(f, check)
        return try {
            val md = MessageDigest.getInstance("SHA-1")
            RandomAccessFile(f, "r").use { raf ->
                val buf = ByteArray(SAMPLE)
                for (off in longArrayOf(0L, size / 2 - SAMPLE / 2, size - SAMPLE)) {
                    raf.seek(off)
                    raf.readFully(buf)
                    md.update(buf)
                }
            }
            hex(md)
        } catch (e: IOException) {
            null
        } catch (e: SecurityException) {
            null
        }
    }

    private fun fullHash(f: File, check: () -> Unit): String? = try {
        val md = MessageDigest.getInstance("SHA-1")
        f.inputStream().use { s ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                check()
                val n = s.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        hex(md)
    } catch (e: IOException) {
        null
    } catch (e: SecurityException) {
        null
    }
}
